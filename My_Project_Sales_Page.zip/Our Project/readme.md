# 1. A simple _README_ file explaining:

# How the work was split:

- The work was slipted into 5 groups.
- Each group composed of atleast 2 members.
- Each group member had to collaborate to come out with the design as it was design by our designer.
- Each member had to code individually to strengthen their ability to code as professionals and be creative.
- When the project was terminated, all the group members submitted thier job to the group leader and explain all what they did in details to the group leader while showing the work live on their PC's screen.

# How to open the project:

- All the work was been gahered in a single folder to form one complet project for easy accesss and use.
- When you right-click on the project, the project opens on a single page, cobining all the parts of the project (Home, About, Review, Product and Contact).
- The project is made of sections (Home, About, Review, Product and Contact) for easy access and navigation.

# Any design inspiration:

- We added the _animation_ property on one of the button in the project.
- We equally added ome real life simulations on the project.

# 2. A Teamwork Reflection:

# What worked well as a team:

- The collaboration.
- The communication amongs the group members.
- Combination of all the work done by each group in a single folder to form a project.

# What challenges were faced:

- We faced some challenges in inserting or joining all the work as a single project.

# Pros and Cons of Collaboration:

- The collaboration permited us to know and learn how to work as a group, share ideas and choose the best.
- The collaboration permited us to know how to work in a company or interprise and interact with other workers to produce high quallity output or end-product.
- It permitted me the group leader to know to rule and collaborate with my group memebers.

# Cons of Collaboration:

- Each group member had his/her own way of reaching the end-point (different mind-set).

# 3. A Statement from each Memeber:

# What they personally workd on:

- Each group worked on seperate seperate parts of the project, that is one group worked on the _Home section_ another on the _About section_ etc...

# Any lessons learned:

- We learned the we must follow the instructions of the costumer.
- We must design exactly what was given to us by the designer.
- We must not use too much _animations_ in a project because it causes alot of destraction to thr end-users.
- We learned how to work and collaborate in a real life situation.

# 4. Design Deliverable (UI/UX Designers)

# Choice on layout structure:

- We sat together with designer and decided on the layout structure to use.
- We decided on the alignments to be used.

# Use of Typography and color from the brand pallete:

- We equally decided the Typography and colors to be used as stated by the costumer Ngwa Che & Associates

# Component heirarchy and spacing:

- We used the knowledge of FIFO (First In First Out) and first come, first served for the heirarchy.
- For the spacing, we used some HTML & CSS proporties to properly space our works.

# Any accessibility or responsiveness considerations:

- The website is highly responsive.

# 5. Development Deliverables (Frontend Developers)

# Flexbox vs. Grid usage:

- We used the _Grid property_ to align all the items in the product section.
- We use the _Flexbox property_ to the contens of the headers and the footers of the page.

# Mobile-first or desktop-first approach:

- We made the website in such a way that it can work on both Mobile phones and desktops without any problem.

# Section padding, margins, and element spacing:

-

# Technique used to match the visual layout:

- We used the knowledge we got from flexbox, grids to make all the elements to be in the form off a grid.
- We used marging and padding to space out the work for more visibility and readability.

# Responsive design methods:

- Clear and proper arrangement of out work.

# Challenges faced and how they were solved:

- Some group members faced the problem of aligning items but the problem was resolved using _Flexbox and Grid propeties_.
- Some memebers faced the problem of inserting a backgroung-image but they later made some research online and understood how to insert it.
- Some members equally faced the problem of spacing and they asked the other group members who knew and it was properly explained to them and they adjusted thier work.
- Some members faced the problem of inserting an icon and the favicon but other group members showed them how to do it.
- Some members were confused when styling the project because the _divs_ were too much and confussing but they brought it to the roup leader and he debugged the problem.
