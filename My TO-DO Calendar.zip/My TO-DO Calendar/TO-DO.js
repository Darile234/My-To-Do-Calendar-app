// --- Utility Functions ---
function getToday() {
    const today = new Date();
    return today.toISOString().split('T')[0];
}

function getTasks() {
    return JSON.parse(localStorage.getItem('tasks') || '[]');
}

function saveTasks(tasks) {
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function groupTasksByDate(tasks) {
    return tasks.reduce((acc, task) => {
        (acc[task.dueDate] = acc[task.dueDate] || []).push(task);
        return acc;
    }, {});
}

// --- Modal Logic ---
const modal = document.getElementById('modal');
const addTaskBtn = document.getElementById('addTaskBtn');
const closeModal = document.getElementById('closeModal');
const taskForm = document.getElementById('taskForm');
const dueDateInput = document.getElementById('dueDate');

addTaskBtn.onclick = () => {
    modal.style.display = 'block';
    dueDateInput.value = selectedDate;
};
closeModal.onclick = () => modal.style.display = 'none';
window.onclick = (e) => { if (e.target === modal) modal.style.display = 'none'; };

// --- Calendar Rendering ---
const calendarDiv = document.getElementById('calendar');
const tasksDiv = document.getElementById('tasks');

// Calendar state
let calendarState = (() => {
    const today = new Date();
    return {
        year: today.getFullYear(),
        month: today.getMonth(),
        day: today.getDate()
    };
})();
let selectedDate = getToday();

function setSelectedDate(year, month, day) {
    const date = new Date(year, month, day);
    selectedDate = date.toISOString().split('T')[0];
    calendarState.year = year;
    calendarState.month = month;
    calendarState.day = day;
}

function renderCalendar(tasksByDate) {
    const { year, month } = calendarState;
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();

    // Navigation header
    let html = `
    <div class="calendar-header">
        <button class="nav-btn" id="prevYearBtn">&laquo;</button>
        <button class="nav-btn" id="prevMonthBtn">&lt;</button>
        <span class="calendar-title">${firstDay.toLocaleString('default', { month: 'long' })} ${year}</span>
        <button class="nav-btn" id="nextMonthBtn">&gt;</button>
        <button class="nav-btn" id="nextYearBtn">&raquo;</button>
        <button class="nav-btn" id="todayBtn">Today</button>
    </div>
    <div class="calendar-grid">
        ${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d=>`<div class="calendar-dayname">${d}</div>`).join('')}
    `;

    let dayOfWeek = firstDay.getDay();
    for (let i = 0; i < dayOfWeek; i++) html += `<div></div>`;

    for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = new Date(year, month, day).toISOString().split('T')[0];
        const hasTasks = tasksByDate[dateStr];
        html += `<div class="calendar-day${dateStr === selectedDate ? ' selected' : ''}" data-date="${dateStr}">
            <span>${day}</span>
            ${hasTasks ? `<span class="dot"></span>` : ''}
        </div>`;
    }
    html += '</div>';
    calendarDiv.innerHTML = html;

    // Navigation events
    document.getElementById('prevMonthBtn').onclick = () => {
        if (calendarState.month === 0) {
            calendarState.year -= 1;
            calendarState.month = 11;
        } else {
            calendarState.month -= 1;
        }
        setSelectedDate(calendarState.year, calendarState.month, 1);
        rerender();
    };
    document.getElementById('nextMonthBtn').onclick = () => {
        if (calendarState.month === 11) {
            calendarState.year += 1;
            calendarState.month = 0;
        } else {
            calendarState.month += 1;
        }
        setSelectedDate(calendarState.year, calendarState.month, 1);
        rerender();
    };
    document.getElementById('prevYearBtn').onclick = () => {
        calendarState.year -= 1;
        setSelectedDate(calendarState.year, calendarState.month, 1);
        rerender();
    };
    document.getElementById('nextYearBtn').onclick = () => {
        calendarState.year += 1;
        setSelectedDate(calendarState.year, calendarState.month, 1);
        rerender();
    };
    document.getElementById('todayBtn').onclick = () => {
        const today = new Date();
        calendarState.year = today.getFullYear();
        calendarState.month = today.getMonth();
        calendarState.day = today.getDate();
        setSelectedDate(calendarState.year, calendarState.month, calendarState.day);
        rerender();
    };

    // Day click events
    document.querySelectorAll('.calendar-day').forEach(dayEl => {
        dayEl.onclick = () => {
            selectedDate = dayEl.getAttribute('data-date');
            const d = new Date(selectedDate);
            calendarState.year = d.getFullYear();
            calendarState.month = d.getMonth();
            calendarState.day = d.getDate();
            rerender();
        };
    });
}

function rerender() {
    const grouped = groupTasksByDate(getTasks());
    renderCalendar(grouped);
    renderTasks(grouped[selectedDate] || []);
}

// --- Tasks Rendering ---
function renderTasks(tasks) {
    if (!tasks.length) {
        tasksDiv.innerHTML = `<p class="no-tasks">No tasks for this date.</p>`;
        return;
    }
    tasksDiv.innerHTML = tasks.map((task, idx) => `
        <div class="task ${task.priority.toLowerCase()}${task.done ? ' done' : ''}">
            <div class="task-header">
                <span class="task-title">${task.done ? '<s>' + task.title + '</s>' : task.title}</span>
                <span class="task-priority">${task.priority}</span>
            </div>
            <div class="task-desc">${task.description ? (task.done ? '<s>' + task.description + '</s>' : task.description) : ''}</div>
            <div class="task-actions">
                <button class="done-btn" data-idx="${idx}">${task.done ? 'Undo' : 'Done'}</button>
                <button class="delete-btn" data-idx="${idx}">Delete</button>
            </div>
        </div>
    `).join('');

    // Add event listeners for buttons
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.onclick = (e) => {
            deleteTask(selectedDate, parseInt(btn.getAttribute('data-idx')));
        };
    });
    document.querySelectorAll('.done-btn').forEach(btn => {
        btn.onclick = (e) => {
            toggleDoneTask(selectedDate, parseInt(btn.getAttribute('data-idx')));
        };
    });
}

function deleteTask(date, idx) {
    let tasks = getTasks();
    const grouped = groupTasksByDate(tasks);
    if (!grouped[date]) return;
    // Find the task in the original array
    const taskToDelete = grouped[date][idx];
    tasks = tasks.filter(t => t !== taskToDelete);
    saveTasks(tasks);
    rerender();
}

function toggleDoneTask(date, idx) {
    let tasks = getTasks();
    const grouped = groupTasksByDate(tasks);
    if (!grouped[date]) return;
    const taskToToggle = grouped[date][idx];
    // Find and update the task in the original array
    const taskIndex = tasks.indexOf(taskToToggle);
    if (taskIndex > -1) {
        tasks[taskIndex].done = !tasks[taskIndex].done;
        saveTasks(tasks);
        rerender();
    }
}

// --- Form Submission ---
taskForm.onsubmit = function(e) {
    e.preventDefault();
    const tasks = getTasks();
    const task = {
        title: document.getElementById('title').value.trim(),
        description: document.getElementById('description').value.trim(),
        dueDate: document.getElementById('dueDate').value,
        priority: document.getElementById('priority').value,
        done: false
    };
    tasks.push(task);
    saveTasks(tasks);
    modal.style.display = 'none';
    taskForm.reset();
    dueDateInput.value = selectedDate;
    rerender();
};

// --- Initial Render ---
setSelectedDate(calendarState.year, calendarState.month, calendarState.day);
rerender();

// ...existing code...